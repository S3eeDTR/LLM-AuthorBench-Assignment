OVERLEAF SOURCE PROJECT

Upload the ZIP as a new Overleaf project. Set main.tex as the main document.
The default pdfLaTeX compiler is suitable. Edit one section at a time in sections/.
Edit the title and author list in main.tex; edit citations in references.tex.
Figures are in figures/ when present. Text and references were preserved during splitting.
This is editable source, not a new experiment or a change to the existing PDF.

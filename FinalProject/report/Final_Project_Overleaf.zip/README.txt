Upload this ZIP as a new Overleaf project. Compile main.tex with pdfLaTeX.
Edit each section in sections/; references are in references.tex.
The fresh-generation section separates the earlier run from a paired coverage comparison on the second run.
Original benchmark training and results are unchanged.
